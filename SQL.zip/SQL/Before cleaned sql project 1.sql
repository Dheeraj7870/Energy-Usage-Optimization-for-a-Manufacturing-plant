SELECT * FROM project.glass_manufacturing_energy_optimization;


#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Production_Output (tons)`) AS `mean_Production_Output (tons)`
FROM glass_manufacturing_energy_optimization;

#median

SELECT AVG(`Production_Output (tons)`) AS median_Column5
FROM (
    SELECT 
        `Production_Output (tons)`, 
        ROW_NUMBER() OVER (ORDER BY `Production_Output (tons)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    #mode

SELECT `Production_Output (tons)` AS mode_Column3
FROM (
    SELECT `Production_Output (tons)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Production_Output (tons)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment

#Variance

SELECT VARIANCE(`Production_Output (tons)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;

#Standard Deviation

SELECT STDDEV(`Production_Output (tons)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Production_Output (tons)`) - MIN(`Production_Output (tons)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Production_Output (tons)`- (SELECT AVG(`Production_Output (tons)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Production_Output (tons)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Production_Output (tons)`- (SELECT AVG(`Production_Output (tons)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Production_Output (tons)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;

#################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Energy_Consumption (kWh)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Energy_Consumption (kWh)`) AS median_Column5
FROM (
    SELECT 
        `Energy_Consumption (kWh)`, 
        ROW_NUMBER() OVER (ORDER BY `Energy_Consumption (kWh)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
#mode

SELECT `Energy_Consumption (kWh)` AS mode_Column3
FROM (
    SELECT `Energy_Consumption (kWh)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Energy_Consumption (kWh)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Energy_Consumption (kWh)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;

#Standard Deviation

SELECT STDDEV(`Energy_Consumption (kWh)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Energy_Consumption (kWh)`) - MIN(`Energy_Consumption (kWh)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;


#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Energy_Consumption (kWh)`- (SELECT AVG(`Energy_Consumption (kWh)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Energy_Consumption (kWh)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;
#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Energy_Consumption (kWh)`- (SELECT AVG(`Energy_Consumption (kWh)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Energy_Consumption (kWh)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;

#######################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Furnace_Temperature (°C)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Furnace_Temperature (°C)`) AS median_Column5
FROM (
    SELECT 
        `Furnace_Temperature (°C)`, 
        ROW_NUMBER() OVER (ORDER BY `Furnace_Temperature (°C)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Furnace_Temperature (°C)` AS mode_Column3
FROM (
    SELECT `Furnace_Temperature (°C)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Furnace_Temperature (°C)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;
   
 #2nd business moment
#Variance

SELECT VARIANCE(`Furnace_Temperature (°C)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Furnace_Temperature (°C)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Furnace_Temperature (°C)`) - MIN(`Furnace_Temperature (°C)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Furnace_Temperature (°C)`- (SELECT AVG(`Furnace_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Furnace_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;
#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Furnace_Temperature (°C)`- (SELECT AVG(`Furnace_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Furnace_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;

#########################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Annealing_Time (hrs)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Annealing_Time (hrs)`) AS median_Column5
FROM (
    SELECT 
        `Annealing_Time (hrs)`, 
        ROW_NUMBER() OVER (ORDER BY `Annealing_Time (hrs)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Annealing_Time (hrs)` AS mode_Column3
FROM (
    SELECT `Annealing_Time (hrs)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Annealing_Time (hrs)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Annealing_Time (hrs)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Annealing_Time (hrs)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Annealing_Time (hrs)`) - MIN(`Annealing_Time (hrs)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Annealing_Time (hrs)`- (SELECT AVG(`Annealing_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Annealing_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Annealing_Time (hrs)`- (SELECT AVG(`Annealing_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Annealing_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;

###################################################################################################################################
   
#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Downtime (hrs)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Downtime (hrs)`) AS median_Column5
FROM (
    SELECT 
        `Downtime (hrs)`, 
        ROW_NUMBER() OVER (ORDER BY `Downtime (hrs)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);

#mode

SELECT `Downtime (hrs)` AS mode_Column3
FROM (
    SELECT `Downtime (hrs)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Downtime (hrs)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment

#Variance

SELECT VARIANCE(`Downtime (hrs)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;

#Standard Deviation

SELECT STDDEV(`Downtime (hrs)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Downtime (hrs)`) - MIN(`Downtime (hrs)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Downtime (hrs)`- (SELECT AVG(`Downtime (hrs)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Downtime (hrs)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Downtime (hrs)`- (SELECT AVG(`Downtime (hrs)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Downtime (hrs)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;

##########################################################################################################################

 #1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Ambient_Temperature (°C)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Ambient_Temperature (°C)`) AS median_Column5
FROM (
    SELECT 
        `Ambient_Temperature (°C)`, 
        ROW_NUMBER() OVER (ORDER BY `Ambient_Temperature (°C)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Ambient_Temperature (°C)` AS mode_Column3
FROM (
    SELECT `Ambient_Temperature (°C)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Ambient_Temperature (°C)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Ambient_Temperature (°C)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Ambient_Temperature (°C)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Ambient_Temperature (°C)`) - MIN(`Ambient_Temperature (°C)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Ambient_Temperature (°C)`- (SELECT AVG(`Ambient_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Ambient_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Ambient_Temperature (°C)`- (SELECT AVG(`Ambient_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Ambient_Temperature (°C)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

###################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Recycled_Content (%)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Recycled_Content (%)`) AS median_Column5
FROM (
    SELECT 
        `Recycled_Content (%)`, 
        ROW_NUMBER() OVER (ORDER BY `Recycled_Content (%)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Recycled_Content (%)` AS mode_Column3
FROM (
    SELECT `Recycled_Content (%)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Recycled_Content (%)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Recycled_Content (%)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Recycled_Content (%)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Recycled_Content (%)`) - MIN(`Recycled_Content (%)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Recycled_Content (%)`- (SELECT AVG(`Recycled_Content (%)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Recycled_Content (%)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Recycled_Content (%)`- (SELECT AVG(`Recycled_Content (%)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Recycled_Content (%)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

###########################################################################################################################
#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Energy_Rating`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Energy_Rating`) AS median_Column5
FROM (
    SELECT 
        `Energy_Rating`, 
        ROW_NUMBER() OVER (ORDER BY `Energy_Rating`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Energy_Rating` AS mode_Column3
FROM (
    SELECT `Energy_Rating`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Energy_Rating`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Energy_Rating`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Energy_Rating`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Energy_Rating`) - MIN(`Energy_Rating`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Energy_Rating`- (SELECT AVG(`Energy_Rating`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Energy_Rating`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Energy_Rating`- (SELECT AVG(`Energy_Rating`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Energy_Rating`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

###############################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Maintenance_Flag`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Maintenance_Flag`) AS median_Column5
FROM (
    SELECT 
        `Maintenance_Flag`, 
        ROW_NUMBER() OVER (ORDER BY `Maintenance_Flag`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Maintenance_Flag` AS mode_Column3
FROM (
    SELECT `Maintenance_Flag`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Maintenance_Flag`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Maintenance_Flag`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Maintenance_Flag`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Maintenance_Flag`) - MIN(`Maintenance_Flag`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Maintenance_Flag`- (SELECT AVG(`Maintenance_Flag`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Maintenance_Flag`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Maintenance_Flag`- (SELECT AVG(`Maintenance_Flag`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Maintenance_Flag`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

###################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Fuel_Type`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Fuel_Type`) AS median_Column5
FROM (
    SELECT 
        `Fuel_Type`, 
        ROW_NUMBER() OVER (ORDER BY `Fuel_Type`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Fuel_Type` AS mode_Column3
FROM (
    SELECT `Fuel_Type`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Fuel_Type`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Fuel_Type`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Fuel_Type`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Fuel_Type`) - MIN(`Fuel_Type`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Fuel_Type`- (SELECT AVG(`Fuel_Type`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Fuel_Type`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Fuel_Type`- (SELECT AVG(`Fuel_Type`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Fuel_Type`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

##############################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Glass_Thickness (mm)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Glass_Thickness (mm)`) AS median_Column5
FROM (
    SELECT 
        `Glass_Thickness (mm)`, 
        ROW_NUMBER() OVER (ORDER BY `Glass_Thickness (mm)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Glass_Thickness (mm)` AS mode_Column3
FROM (
    SELECT `Glass_Thickness (mm)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Glass_Thickness (mm)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Glass_Thickness (mm)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Glass_Thickness (mm)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Glass_Thickness (mm)`) - MIN(`Glass_Thickness (mm)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Glass_Thickness (mm)`- (SELECT AVG(`Glass_Thickness (mm)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Glass_Thickness (mm)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Glass_Thickness (mm)`- (SELECT AVG(`Glass_Thickness (mm)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Glass_Thickness (mm)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

#################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Production_Target (tons)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Production_Target (tons)`) AS median_Column5
FROM (
    SELECT 
        `Production_Target (tons)`, 
        ROW_NUMBER() OVER (ORDER BY `Production_Target (tons)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Production_Target (tons)` AS mode_Column3
FROM (
    SELECT `Production_Target (tons)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Production_Target (tons)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Production_Target (tons)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Production_Target (tons)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Production_Target (tons)`) - MIN(`Production_Target (tons)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Production_Target (tons)`- (SELECT AVG(`Production_Target (tons)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Production_Target (tons)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Production_Target (tons)`- (SELECT AVG(`Production_Target (tons)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Production_Target (tons)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

##########################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Defects_Percentage (%)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Defects_Percentage (%)`) AS median_Column5
FROM (
    SELECT 
        `Defects_Percentage (%)`, 
        ROW_NUMBER() OVER (ORDER BY `Defects_Percentage (%)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Defects_Percentage (%)` AS mode_Column3
FROM (
    SELECT `Defects_Percentage (%)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Defects_Percentage (%)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Defects_Percentage (%)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Defects_Percentage (%)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Defects_Percentage (%)`) - MIN(`Defects_Percentage (%)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Defects_Percentage (%)`- (SELECT AVG(`Defects_Percentage (%)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Defects_Percentage (%)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Defects_Percentage (%)`- (SELECT AVG(`Defects_Percentage (%)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Defects_Percentage (%)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization;   

################################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Melting_Time (hrs)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Melting_Time (hrs)`) AS median_Column5
FROM (
    SELECT 
        `Melting_Time (hrs)`, 
        ROW_NUMBER() OVER (ORDER BY `Melting_Time (hrs)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Melting_Time (hrs)` AS mode_Column3
FROM (
    SELECT `Melting_Time (hrs)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Melting_Time (hrs)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Melting_Time (hrs)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Melting_Time (hrs)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Melting_Time (hrs)`) - MIN(`Melting_Time (hrs)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Melting_Time (hrs)`- (SELECT AVG(`Melting_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Melting_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Melting_Time (hrs)`- (SELECT AVG(`Melting_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Melting_Time (hrs)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization; 

#############################################################################################################################

#1st business moment (Mean/Median/Mode)
#mean

SELECT AVG(`Cooling_Energy (kWh)`) AS mean_column
FROM glass_manufacturing_energy_optimization
LIMIT 0, 1000;

#median

SELECT AVG(`Cooling_Energy (kWh)`) AS median_Column5
FROM (
    SELECT 
        `Cooling_Energy (kWh)`, 
        ROW_NUMBER() OVER (ORDER BY `Cooling_Energy (kWh)`) AS row_num,
        COUNT(*) OVER () AS total_count
    FROM glass_manufacturing_energy_optimization
) AS subquery
WHERE 
    row_num = FLOOR((total_count + 1) / 2) 
    OR row_num = CEIL((total_count + 1) / 2);
    
    
 #mode

SELECT `Cooling_Energy (kWh)` AS mode_Column3
FROM (
    SELECT `Cooling_Energy (kWh)`, COUNT(*) AS frequency
    FROM glass_manufacturing_energy_optimization
    GROUP BY `Cooling_Energy (kWh)`
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

#2nd business moment
#Variance

SELECT VARIANCE(`Cooling_Energy (kWh)`) AS performance_variance
FROM glass_manufacturing_energy_optimization;  

#Standard Deviation

SELECT STDDEV(`Cooling_Energy (kWh)`) AS Column4_stddev
FROM glass_manufacturing_energy_optimization;

#Range

SELECT MAX(`Cooling_Energy (kWh)`) - MIN(`Cooling_Energy (kWh)`) AS Column5_range
FROM glass_manufacturing_energy_optimization;

#3rd business moment

#Skewness

SELECT
(
SUM(POWER(`Cooling_Energy (kWh)`- (SELECT AVG(`Cooling_Energy (kWh)`) FROM glass_manufacturing_energy_optimization), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Cooling_Energy (kWh)`) FROM glass_manufacturing_energy_optimization), 3))
) AS skewness

FROM glass_manufacturing_energy_optimization;

#4th business moment
#Kurtosis

SELECT
(
(SUM(POWER(`Cooling_Energy (kWh)`- (SELECT AVG(`Cooling_Energy (kWh)`) FROM glass_manufacturing_energy_optimization), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Cooling_Energy (kWh)`) FROM glass_manufacturing_energy_optimization), 4))) - 3
) AS kurtosis
FROM glass_manufacturing_energy_optimization; 
